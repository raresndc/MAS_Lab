package com.example.mobilecomms;

public final class ApiEndPoints {

    public final static String GET_PUBLIC_KEY = "api/getPublicKey";
    public final static String POST_PUBLIC_KEY = "api/postPublicKey";
    public final static String SEND_MESSAGE = "api/postMessage";

}
