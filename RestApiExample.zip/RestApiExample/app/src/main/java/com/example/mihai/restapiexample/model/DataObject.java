package com.example.mihai.restapiexample.model;

public class DataObject {

    public final String value;

    public DataObject(String value) {
        this.value = value;
    }
}
